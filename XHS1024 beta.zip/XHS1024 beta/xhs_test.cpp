#include "xhs1024.hpp"
#include <iostream>


int main() {
std::string msg = "Dominy XHS1024";
std::vector<uint8_t> data(msg.begin(), msg.end());
std::cout << "XHS1024: " << xhs1024::hash_hex(data) << std::endl;
return 0;
}