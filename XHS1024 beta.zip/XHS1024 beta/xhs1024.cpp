#include "xhs1024.hpp"
{0xBA7C9045F12C7F99ULL, 0x24A19947B3916CF7ULL},
{0x0801F2E2858EFC16ULL, 0x636920D871574E69ULL}
}};


static const unsigned ROT[8] = {11, 23, 41, 59, 73, 97, 13, 37};


static const word128 RC[256] = []{
std::array<word128,256> c{};
uint64_t x = 0x9E3779B97F4A7C15ULL;
for (size_t i = 0; i < 256; ++i) {
x ^= x >> 12; x ^= x << 25; x ^= x >> 27;
uint64_t y = x * 0x2545F4914F6CDD1DULL;
c[i] = {x, y};
}
return c;
}();


static void permute(state1024& s) {
state1024 t = s;
s[0]=t[3]; s[1]=t[5]; s[2]=t[7]; s[3]=t[1];
s[4]=t[6]; s[5]=t[0]; s[6]=t[2]; s[7]=t[4];
}


static void compress(state1024& s, const state1024& m) {
for (size_t r = 0; r < 256; ++r) {
for (size_t i = 0; i < 8; ++i) {
s[i] = add128(s[i], m[(i + r) & 7]);
s[i] = xor128(s[i], RC[r]);
s[i] = rotl128(s[i], ROT[i]);
}
permute(s);
}
}


static std::vector<uint8_t> pad(const std::vector<uint8_t>& data) {
std::vector<uint8_t> out = data;
uint64_t bitlen = static_cast<uint64_t>(data.size()) * 8;
out.push_back(0x80);
while ((out.size() * 8) % 2048 != 1920) out.push_back(0);
for (int i = 15; i >= 0; --i)
out.push_back(static_cast<uint8_t>((bitlen >> (i*8)) & 0xFF));
return out;
}


state1024 hash(const std::vector<uint8_t>& data) {
state1024 s = IV;
auto msg = pad(data);
for (size_t off = 0; off < msg.size(); off += 256) {
state1024 m{};
for (size_t i = 0; i < 8; ++i) {
uint64_t lo = 0, hi = 0;
for (int b = 0; b < 8; ++b) lo = (lo << 8) | msg[off + i*16 + b];
for (int b = 0; b < 8; ++b) hi = (hi << 8) | msg[off + i*16 + 8 + b];
m[i] = {lo, hi};
}
compress(s, m);
}
return s;
}


std::string hash_hex(const std::vector<uint8_t>& data) {
auto h = hash(data);
std::ostringstream oss;
for (auto& w : h) {
oss << std::hex << std::setw(16) << std::setfill('0') << w[0]
<< std::setw(16) << std::setfill('0') << w[1];
}
return oss.str();
}


}