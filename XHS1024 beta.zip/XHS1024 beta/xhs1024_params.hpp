#pragma once
#include <array>
#include <cstdint>
#include <cstddef>

namespace xhs1024 {

    /*
        =========================
        XHS1024 — Design Parameters
        =========================

        Hash criptográfico de 1024 bits
        Projetado para margem de segurança pós-Grover
        Estrutura clara, determinística e auditável
    */

    // -------------------------
    // Parâmetros fundamentais
    // -------------------------

    constexpr std::size_t HASH_BITS        = 1024;
    constexpr std::size_t HASH_BYTES       = HASH_BITS / 8;

    constexpr std::size_t WORD_BITS        = 1024;
    constexpr std::size_t WORD_BYTES       = WORD_BITS / 8;

    constexpr std::size_t STATE_WORDS      = 8;      // 8 palavras de 1024 bits
    constexpr std::size_t STATE_BITS       = STATE_WORDS * WORD_BITS;

    constexpr std::size_t BLOCK_BITS       = 2048;   // bloco processado
    constexpr std::size_t BLOCK_BYTES      = BLOCK_BITS / 8;

    constexpr std::size_t ROUNDS           = 256;    // fixo, não negociável

    // -------------------------
    // Tipos fundamentais
    // -------------------------

    using byte  = uint8_t;

    // Palavra de 1024 bits
    using word1024 = std::array<byte, WORD_BYTES>;

    // Estado interno: 8 × 1024 bits
    using state1024 = std::array<word1024, STATE_WORDS>;

    // Bloco de entrada
    using block2048 = std::array<byte, BLOCK_BYTES>;

    // Hash final
    using hash1024 = std::array<byte, HASH_BYTES>;

    // -------------------------
    // Constantes criptográficas
    // -------------------------

    /*
        Constantes devem:
        - não ser triviais
        - não conter padrões simples
        - ser independentes da mensagem
        - garantir quebra de simetria inicial
    */

    extern const state1024 IV;

    /*
        Rotações fixas por palavra.
        Variam por índice para evitar simetria estrutural.
    */
    extern const std::array<uint32_t, STATE_WORDS> ROTATIONS;

    // -------------------------
    // Operações de baixo nível
    // -------------------------

    // Rotação circular à esquerda em uma palavra de 1024 bits
    void rotl(word1024& w, uint32_t bits);

    // ADD módulo 2^1024
    void add_mod(word1024& a, const word1024& b);

    // XOR palavra inteira
    void xor_word(word1024& a, const word1024& b);

    // -------------------------
    // Compressão e rounds
    // -------------------------

    /*
        Executa UM round completo do XHS1024.
        Determinístico, sem branches dependentes de dados.
    */
    void round_function(state1024& state,
                        const block2048& block,
                        std::size_t round_index);

    /*
        Função de compressão:
        Mistura bloco de 2048 bits no estado interno
    */
    void compress(state1024& state,
                  const block2048& block);

} // namespace xhs1024