#pragma once
#include <fstream>
#include <string>
#include <chrono>
#include <iomanip>

class Logger {
private:
    std::ofstream ofs;
public:
    Logger(const std::string& filename) {
        ofs.open(filename, std::ios::out | std::ios::trunc);
    }
    ~Logger() {
        if (ofs.is_open()) ofs.close();
    }
    void write(const std::string& msg) {
        if (!ofs.is_open()) return;
        auto now = std::chrono::system_clock::now();
        auto time = std::chrono::system_clock::to_time_t(now);
        ofs << "[" << std::put_time(std::localtime(&time), "%F %T") << "] " << msg << "\n";
    }
};