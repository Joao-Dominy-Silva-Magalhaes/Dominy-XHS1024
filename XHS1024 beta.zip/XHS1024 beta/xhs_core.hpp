#pragma once
#include "xhs1024_types.hpp"

namespace xhs1024 {

static constexpr size_t BLOCK_BYTES = 256; // 2048 bits
static constexpr size_t DIGEST_BYTES = 128; // 1024 bits
static constexpr size_t ROUNDS = 256;

void compress(u128 state[8], const uint8_t block[BLOCK_BYTES]);

}