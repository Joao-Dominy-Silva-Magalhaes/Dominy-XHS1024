#pragma once
#include <cstdint>
#include <cstring>

/*
 XHS1024 – tipos fundamentais
 Palavra base: 128 bits
*/

namespace xhs1024 {

struct u128 {
    uint64_t lo;
    uint64_t hi;

    constexpr u128() : lo(0), hi(0) {}
    constexpr u128(uint64_t low, uint64_t high) : lo(low), hi(high) {}

    static constexpr u128 zero() {
        return u128(0, 0);
    }
};

/* XOR */
inline u128 operator^(const u128& a, const u128& b) {
    return u128(a.lo ^ b.lo, a.hi ^ b.hi);
}

/* ADD módulo 2^128 */
inline u128 operator+(const u128& a, const u128& b) {
    uint64_t lo = a.lo + b.lo;
    uint64_t carry = (lo < a.lo) ? 1 : 0;
    uint64_t hi = a.hi + b.hi + carry;
    return u128(lo, hi);
}

/* Rotação à esquerda */
inline u128 rotl(const u128& x, unsigned r) {
    r &= 127;
    if (r == 0) return x;

    if (r < 64) {
        return u128(
            (x.lo << r) | (x.hi >> (64 - r)),
            (x.hi << r) | (x.lo >> (64 - r))
        );
    } else {
        r -= 64;
        return u128(
            (x.hi << r) | (x.lo >> (64 - r)),
            (x.lo << r) | (x.hi >> (64 - r))
        );
    }
}

/* Carregar u128 de bytes (little endian) */
inline u128 load_u128(const uint8_t* p) {
    u128 v;
    std::memcpy(&v.lo, p, 8);
    std::memcpy(&v.hi, p + 8, 8);
    return v;
}

/* Armazenar u128 em bytes */
inline void store_u128(uint8_t* p, const u128& v) {
    std::memcpy(p, &v.lo, 8);
    std::memcpy(p + 8, &v.hi, 8);
}

} // namespace xhs1024