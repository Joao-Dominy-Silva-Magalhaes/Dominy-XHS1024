#pragma once
#include <vector>
#include <cstddef>

namespace xhs1024 {

std::vector<uint8_t> hash(const uint8_t* data, size_t len);

}